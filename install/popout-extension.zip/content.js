(function () {
  const STORAGE_KEY = `popout:${location.hostname}`;
  const popped = new Map(); // element -> state

  function cssPath(el) {
    if (el.id && document.querySelectorAll(`#${CSS.escape(el.id)}`).length === 1) {
      return `#${CSS.escape(el.id)}`;
    }
    const parts = [];
    let node = el;
    while (node && node.nodeType === 1 && node !== document.body) {
      if (node.id && document.querySelectorAll(`#${CSS.escape(node.id)}`).length === 1) {
        parts.unshift(`#${CSS.escape(node.id)}`);
        break;
      }
      let selector = node.tagName.toLowerCase();
      let sibling = node;
      let nth = 1;
      while ((sibling = sibling.previousElementSibling)) {
        if (sibling.tagName === node.tagName) nth++;
      }
      selector += `:nth-of-type(${nth})`;
      parts.unshift(selector);
      node = node.parentElement;
    }
    return parts.join(" > ");
  }

  async function loadConfigs() {
    const data = await chrome.storage.local.get(STORAGE_KEY);
    return data[STORAGE_KEY] || [];
  }

  async function saveConfig(cfg) {
    const configs = (await loadConfigs()).filter((c) => c.selector !== cfg.selector);
    configs.push(cfg);
    await chrome.storage.local.set({ [STORAGE_KEY]: configs });
  }

  async function removeConfig(selector) {
    const configs = (await loadConfigs()).filter((c) => c.selector !== selector);
    await chrome.storage.local.set({ [STORAGE_KEY]: configs });
  }

  function currentConfig(el, state) {
    const r = el.getBoundingClientRect();
    return {
      selector: state.selector,
      top: r.top,
      left: r.left,
      width: r.width,
      height: r.height,
      fullscreen: state.fullscreen,
      opacity: state.opacity,
      draggable: state.draggable,
      resizable: state.resizable,
      bgTransparent: state.bgTransparent,
    };
  }

  function applyRect(el, rect) {
    el.style.top = `${rect.top}px`;
    el.style.left = `${rect.left}px`;
    el.style.width = `${rect.width}px`;
    el.style.height = `${rect.height}px`;
  }

  function makeToolbar(el, state) {
    const bar = document.createElement("div");
    bar.className = "popout-ext-toolbar";

    const fsBtn = document.createElement("button");
    fsBtn.textContent = "⛶ Fullscreen";
    fsBtn.onclick = () => toggleFullscreen(el, state);

    const restoreBtn = document.createElement("button");
    restoreBtn.textContent = "✕ Restore";
    restoreBtn.onclick = () => restore(el);

    const dragLabel = document.createElement("label");
    const dragBox = document.createElement("input");
    dragBox.type = "checkbox";
    dragBox.checked = state.draggable;
    dragBox.onchange = () => {
      state.draggable = dragBox.checked;
      persist(el, state);
    };
    dragLabel.append(dragBox, "drag");

    const resizeLabel = document.createElement("label");
    const resizeBox = document.createElement("input");
    resizeBox.type = "checkbox";
    resizeBox.checked = state.resizable;
    resizeBox.onchange = () => {
      state.resizable = resizeBox.checked;
      el.style.resize = state.resizable ? "both" : "none";
      persist(el, state);
    };
    resizeLabel.append(resizeBox, "resize");

    const opLabel = document.createElement("label");
    const opSlider = document.createElement("input");
    opSlider.type = "range";
    opSlider.min = "20";
    opSlider.max = "100";
    opSlider.value = String(Math.round(state.opacity * 100));
    opSlider.oninput = () => {
      state.opacity = Number(opSlider.value) / 100;
      el.style.opacity = String(state.opacity);
      persist(el, state);
    };
    opLabel.append("opacity", opSlider);

    const bgLabel = document.createElement("label");
    const bgBox = document.createElement("input");
    bgBox.type = "checkbox";
    bgBox.checked = state.bgTransparent;
    bgBox.onchange = () => toggleBgTransparent(el, bgBox.checked);
    bgLabel.append(bgBox, "bg transparent");
    state.bgCheckbox = bgBox;

    const pipBtn = document.createElement("button");
    pipBtn.textContent = "⧉ PiP";
    pipBtn.onclick = () => enterPiP(el);

    bar.append(fsBtn, pipBtn, restoreBtn, dragLabel, resizeLabel, opLabel, bgLabel);
    return bar;
  }

  function persist(el, state) {
    saveConfig(currentConfig(el, state));
  }

  function toggleBgTransparent(el, value) {
    const state = popped.get(el);
    if (!state) return;
    state.bgTransparent = typeof value === "boolean" ? value : !state.bgTransparent;
    el.classList.toggle("popout-ext-bgtransparent", state.bgTransparent);
    if (state.bgCheckbox) state.bgCheckbox.checked = state.bgTransparent;
    persist(el, state);
  }

  async function enterPiP(el) {
    const state = popped.get(el);
    if (!state) return;
    if (!("documentPictureInPicture" in window)) {
      alert(
        "This browser doesn't support the Picture-in-Picture window API (documentPictureInPicture)."
      );
      return;
    }
    const r = el.getBoundingClientRect();
    const pipWindow = await documentPictureInPicture.requestWindow({
      width: Math.round(r.width),
      height: Math.round(r.height),
    });

    for (const styleSheet of document.styleSheets) {
      try {
        const rules = [...styleSheet.cssRules].map((rule) => rule.cssText).join("\n");
        const style = document.createElement("style");
        style.textContent = rules;
        pipWindow.document.head.appendChild(style);
      } catch (e) {
        if (styleSheet.href) {
          const link = document.createElement("link");
          link.rel = "stylesheet";
          link.href = styleSheet.href;
          pipWindow.document.head.appendChild(link);
        }
      }
    }

    pipWindow.document.body.style.margin = "0";
    pipWindow.document.body.style.background = state.bgTransparent ? "transparent" : "#000";

    state.pipOriginalParent = el.parentNode;
    state.pipOriginalNextSibling = el.nextSibling;
    state.pipOriginalBar = state.bar;
    state.pipWindow = pipWindow;

    el.style.position = "static";
    el.style.top = "";
    el.style.left = "";
    el.style.width = "100%";
    el.style.height = "100%";
    pipWindow.document.body.appendChild(el);
    state.bar.remove();

    pipWindow.addEventListener("pagehide", () => {
      el.style.position = "fixed";
      applyRect(el, r);
      if (state.pipOriginalNextSibling) {
        state.pipOriginalParent.insertBefore(el, state.pipOriginalNextSibling);
      } else {
        state.pipOriginalParent.appendChild(el);
      }
      document.body.appendChild(state.bar);
      positionToolbar(el, state.bar);
      state.pipWindow = null;
    });
  }

  function toggleFullscreen(el, state) {
    if (!state.fullscreen) {
      state.preFullscreenRect = el.getBoundingClientRect();
      state.fullscreen = true;
      el.style.top = "0px";
      el.style.left = "0px";
      el.style.width = "100vw";
      el.style.height = "100vh";
    } else {
      state.fullscreen = false;
      const r = state.preFullscreenRect;
      if (r) applyRect(el, { top: r.top, left: r.left, width: r.width, height: r.height });
    }
    persist(el, state);
  }

  function wireDrag(el, bar, state) {
    let dragging = false;
    let startX, startY, startTop, startLeft;
    bar.addEventListener("mousedown", (e) => {
      if (!state.draggable || state.fullscreen) return;
      if (e.target.closest("input, button, label")) return;
      dragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const r = el.getBoundingClientRect();
      startTop = r.top;
      startLeft = r.left;
      e.preventDefault();
    });
    window.addEventListener("mousemove", (e) => {
      if (!dragging) return;
      el.style.top = `${startTop + (e.clientY - startY)}px`;
      el.style.left = `${startLeft + (e.clientX - startX)}px`;
    });
    window.addEventListener("mouseup", () => {
      if (dragging) {
        dragging = false;
        persist(el, state);
      }
    });
  }

  function popOut(el, savedCfg) {
    if (popped.has(el)) return;
    const selector = savedCfg ? savedCfg.selector : cssPath(el);
    const originalCssText = el.style.cssText;
    const state = {
      selector,
      fullscreen: savedCfg ? !!savedCfg.fullscreen : false,
      opacity: savedCfg ? savedCfg.opacity : 1,
      draggable: savedCfg ? savedCfg.draggable !== false : true,
      resizable: savedCfg ? savedCfg.resizable !== false : true,
      bgTransparent: savedCfg ? !!savedCfg.bgTransparent : false,
      originalCssText,
      preFullscreenRect: null,
    };

    el.classList.add("popout-ext-popped");
    el.classList.toggle("popout-ext-bgtransparent", state.bgTransparent);
    el.style.position = "fixed";
    el.style.margin = "0";
    el.style.opacity = String(state.opacity);
    el.style.overflow = "auto";
    el.style.resize = state.resizable ? "both" : "none";

    if (savedCfg && savedCfg.fullscreen) {
      el.style.top = "0px";
      el.style.left = "0px";
      el.style.width = "100vw";
      el.style.height = "100vh";
    } else if (savedCfg) {
      applyRect(el, savedCfg);
    } else {
      const r = el.getBoundingClientRect();
      applyRect(el, {
        top: Math.max(20, r.top),
        left: Math.max(20, r.left),
        width: Math.max(320, r.width),
        height: Math.max(240, r.height),
      });
    }

    const bar = makeToolbar(el, state);
    el.style.position = el.style.position; // no-op, keep fixed
    document.body.appendChild(bar);
    state.bar = bar;
    positionToolbar(el, bar);

    const reposition = () => positionToolbar(el, bar);
    const ro = new ResizeObserver(reposition);
    ro.observe(el);
    state.resizeObserver = ro;
    window.addEventListener("scroll", reposition, true);
    state.repositionHandler = reposition;

    wireDrag(el, bar, state);
    popped.set(el, state);
    saveConfig(currentConfig(el, state));
  }

  function positionToolbar(el, bar) {
    const r = el.getBoundingClientRect();
    bar.style.position = "fixed";
    bar.style.top = `${Math.max(0, r.top - 28)}px`;
    bar.style.left = `${r.left}px`;
  }

  function restore(el) {
    const state = popped.get(el);
    if (!state) return;
    if (state.pipWindow) {
      state.pipWindow.close();
    }
    el.classList.remove("popout-ext-popped", "popout-ext-bgtransparent");
    el.style.cssText = state.originalCssText;
    if (state.pipOriginalParent && el.parentNode !== state.pipOriginalParent) {
      if (state.pipOriginalNextSibling) {
        state.pipOriginalParent.insertBefore(el, state.pipOriginalNextSibling);
      } else {
        state.pipOriginalParent.appendChild(el);
      }
    }
    state.bar.remove();
    state.resizeObserver.disconnect();
    window.removeEventListener("scroll", state.repositionHandler, true);
    popped.delete(el);
    removeConfig(state.selector);
  }

  // --- element picker ---
  let picking = false;
  let highlightEl = null;

  function startPicking() {
    if (picking) return;
    picking = true;
    highlightEl = document.createElement("div");
    highlightEl.className = "popout-ext-highlight";
    document.body.appendChild(highlightEl);
    document.addEventListener("mousemove", onPickMove, true);
    document.addEventListener("click", onPickClick, true);
    document.addEventListener("keydown", onPickKey, true);
  }

  function stopPicking() {
    picking = false;
    document.removeEventListener("mousemove", onPickMove, true);
    document.removeEventListener("click", onPickClick, true);
    document.removeEventListener("keydown", onPickKey, true);
    if (highlightEl) {
      highlightEl.remove();
      highlightEl = null;
    }
  }

  function onPickMove(e) {
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (!el || el.closest(".popout-ext-toolbar") || el === highlightEl) return;
    const r = el.getBoundingClientRect();
    highlightEl.style.top = `${r.top}px`;
    highlightEl.style.left = `${r.left}px`;
    highlightEl.style.width = `${r.width}px`;
    highlightEl.style.height = `${r.height}px`;
    highlightEl.dataset.target = "1";
    highlightEl._target = el;
  }

  function onPickClick(e) {
    e.preventDefault();
    e.stopPropagation();
    const el = highlightEl && highlightEl._target;
    stopPicking();
    if (el) popOut(el, null);
  }

  function onPickKey(e) {
    if (e.key === "Escape") stopPicking();
  }

  let lastContextEl = null;
  document.addEventListener(
    "contextmenu",
    (e) => {
      lastContextEl = e.target.closest ? e.target.closest(".popout-ext-popped") : null;
    },
    true
  );

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "POPOUT_TOGGLE_PICKER") {
      if (picking) stopPicking();
      else startPicking();
    } else if (msg.type === "POPOUT_CONTEXT_ACTION") {
      if (!lastContextEl) return;
      if (msg.action === "popout-pip") enterPiP(lastContextEl);
      else if (msg.action === "popout-bgtransparent") toggleBgTransparent(lastContextEl);
    }
  });

  // --- restore saved pop-outs on page load ---
  async function restoreSaved() {
    const configs = await loadConfigs();
    for (const cfg of configs) {
      let tries = 0;
      const tryFind = () => {
        tries++;
        const el = document.querySelector(cfg.selector);
        if (el) {
          popOut(el, cfg);
        } else if (tries < 20) {
          setTimeout(tryFind, 500);
        }
      };
      tryFind();
    }
  }
  restoreSaved();

  // --- outbound relay: poll the local MCP server for text to send as real chat ---
  const RELAY_URL = "http://127.0.0.1:8765/pending";

  function findChatInput() {
    return document.querySelector('[data-testid="chat-input"]');
  }

  function findSendButton() {
    return document.querySelector('[data-testid="send-button"]');
  }

  function sendIntoChat(text) {
    const input = findChatInput();
    const button = findSendButton();
    if (!input || !button) {
      console.warn("Pop Out relay: chat input/send button not found on this page yet.");
      return;
    }
    input.focus();
    document.execCommand("insertText", false, text);
    input.dispatchEvent(new InputEvent("input", { bubbles: true, data: text, inputType: "insertText" }));
    setTimeout(() => button.click(), 150);
  }

  async function pollRelay() {
    try {
      const resp = await fetch(RELAY_URL);
      const data = await resp.json();
      if (data && data.message) {
        sendIntoChat(data.message);
      }
    } catch (e) {
      // Relay not running (MCP server not started) — silently keep trying.
    }
  }

  if (location.hostname.includes("chaturbate.com")) {
    setInterval(pollRelay, 1500);
  }
})();
