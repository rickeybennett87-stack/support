chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "popout-pip",
    title: "Pop Out to Picture-in-Picture Window",
    contexts: ["all"],
  });
  chrome.contextMenus.create({
    id: "popout-bgtransparent",
    title: "Toggle Transparent Background",
    contexts: ["all"],
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || !tab.id) return;
  if (info.menuItemId === "popout-pip" || info.menuItemId === "popout-bgtransparent") {
    chrome.tabs
      .sendMessage(tab.id, { type: "POPOUT_CONTEXT_ACTION", action: info.menuItemId })
      .catch(() => {});
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "POPOUT_TOGGLE_PICKER" });
  } catch (e) {
    // Content script wasn't already injected (tab predates the extension load) — inject now.
    try {
      await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ["content.css"] });
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      await chrome.tabs.sendMessage(tab.id, { type: "POPOUT_TOGGLE_PICKER" });
    } catch (e2) {
      console.error("Pop Out: failed to activate on this tab", e2);
    }
  }
});
